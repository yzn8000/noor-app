import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const green = Color(0xFF123D32);
const gold = Color(0xFFD7B56D);
const channel = MethodChannel('com.noor.app/accessibility');

void main() => runApp(const NoorApp());

class NoorApp extends StatelessWidget {
  const NoorApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'نور',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: green), scaffoldBackgroundColor: const Color(0xFFF7F5EF), appBarTheme: const AppBarTheme(backgroundColor: green, foregroundColor: Colors.white), fontFamily: 'sans-serif'),
    home: const MainShell(),
  );
}

class MainShell extends StatefulWidget { const MainShell({super.key}); @override State<MainShell> createState()=>_MainShellState(); }
class _MainShellState extends State<MainShell> {
  int tab=0;
  final pages = const [HomeTab(), QuranTab(), AdhkarTab(), TasbeehTab(), SettingsTab()];
  final titles = const ['نور','القرآن الكريم','الأذكار','التسبيح','الإعدادات'];
  @override Widget build(BuildContext context)=>Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    appBar: AppBar(title: Text(titles[tab]), centerTitle:true),
    body: pages[tab],
    bottomNavigationBar: NavigationBar(selectedIndex:tab, onDestinationSelected:(v)=>setState(()=>tab=v), destinations: const [NavigationDestination(icon:Icon(Icons.home_outlined),label:'الرئيسية'),NavigationDestination(icon:Icon(Icons.menu_book),label:'القرآن'),NavigationDestination(icon:Icon(Icons.favorite_border),label:'الأذكار'),NavigationDestination(icon:Icon(Icons.fingerprint),label:'التسبيح'),NavigationDestination(icon:Icon(Icons.settings_outlined),label:'الإعدادات')]),
  ));
}

class HomeTab extends StatelessWidget { const HomeTab({super.key});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
  Container(padding:const EdgeInsets.all(22), decoration:BoxDecoration(color:green,borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[green,Color(0xFF246653)])),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('السلام عليك ورحمة الله',style:TextStyle(color:gold,fontSize:16)),SizedBox(height:12),Text('اجعل للقرآن نصيبًا من يومك',style:TextStyle(color:Colors.white,fontSize:23,fontWeight:FontWeight.bold)),SizedBox(height:8),Text('تذكير لطيف يعينك على الذكر والقراءة',style:TextStyle(color:Colors.white70))]),),
  const SizedBox(height:18), const Text('ابدأ من هنا',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:8),
  _HomeCard(icon:Icons.menu_book,title:'تابع قراءة القرآن',subtitle:'افتح المصحف وتابع من آخر صفحة',onTap:()=>_go(context,1)),
  _HomeCard(icon:Icons.notifications_active_outlined,title:'تذكير قبل التطبيقات',subtitle:'إعداد التذكير لمدة 30 ثانية',onTap:()=>_go(context,4)),
  _HomeCard(icon:Icons.favorite_border,title:'الأذكار اليومية',subtitle:'أذكار مختارة للصباح والمساء',onTap:()=>_go(context,2)),
  _HomeCard(icon:Icons.fingerprint,title:'عداد التسبيح',subtitle:'سبح واحفظ عددك على الجهاز',onTap:()=>_go(context,3)),
  const Padding(padding:EdgeInsets.only(top:12),child:Text('ملاحظة: مواقيت الصلاة والتذكير بين التطبيقات يحتاجان إعدادات إضافية حسب جهازك.',style:TextStyle(color:Colors.black54))),
 ]);
 void _go(BuildContext c,int i){ final s=c.findAncestorStateOfType<_MainShellState>(); s?.setState(()=>s.tab=i); }
}
class _HomeCard extends StatelessWidget {final IconData icon;final String title,subtitle;final VoidCallback onTap;const _HomeCard({required this.icon,required this.title,required this.subtitle,required this.onTap});@override Widget build(BuildContext context)=>Card(color:Colors.white,child:ListTile(onTap:onTap,leading:CircleAvatar(backgroundColor:green,child:Icon(icon,color:gold)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(subtitle),trailing:const Icon(Icons.chevron_left)));}

class QuranTab extends StatefulWidget {const QuranTab({super.key});@override State<QuranTab> createState()=>_QuranTabState();}
class _QuranTabState extends State<QuranTab>{int page=1;bool loading=true;String? error;List<dynamic> ayahs=[];@override void initState(){super.initState();_init();}
 Future<void> _init()async{final p=await SharedPreferences.getInstance();page=p.getInt('quranPage')??1;await _load();}
 Future<void> _load()async{setState(()=>{loading=true,error=null});try{final r=await http.get(Uri.parse('https://api.alquran.cloud/v1/page/$page/quran-uthmani')).timeout(const Duration(seconds:15));if(r.statusCode!=200)throw Exception('تعذر تحميل الصفحة');final j=jsonDecode(r.body);ayahs=j['data']['ayahs'] as List<dynamic>;final half=ayahs.take((ayahs.length/2).ceil()).map((a)=>'${a['text']} ۝').join(' ');final prefs=await SharedPreferences.getInstance();await prefs.setInt('quranPage',page);await prefs.setString('reminderText',half.isEmpty?'اقرأ القرآن بتدبر':half);if(mounted)setState(()=>loading=false);}catch(e){if(mounted)setState(()=>{loading=false,error='تعذر الاتصال بالإنترنت. تحقق من الاتصال ثم أعد المحاولة.'});}}
 @override Widget build(BuildContext context)=>Column(children:[Padding(padding:const EdgeInsets.all(12),child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[OutlinedButton.icon(onPressed:page>1?(){setState(()=>page--);_load();}:null,icon:const Icon(Icons.chevron_right),label:const Text('السابقة')),Text('صفحة $page من 604',style:const TextStyle(fontWeight:FontWeight.bold)),OutlinedButton.icon(onPressed:page<604?(){setState(()=>page++);_load();}:null,icon:const Icon(Icons.chevron_left),label:const Text('التالية'))])),Expanded(child:loading?const Center(child:CircularProgressIndicator()):error!=null?Center(child:Padding(padding:const EdgeInsets.all(20),child:Column(mainAxisSize:MainAxisSize.min,children:[Text(error!,textAlign:TextAlign.center),const SizedBox(height:10),ElevatedButton(onPressed:_load,child:const Text('إعادة المحاولة'))])):ListView(padding:const EdgeInsets.all(18),children:[Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:Colors.white,border:Border.all(color:gold),borderRadius:BorderRadius.circular(18)),child:Text(ayahs.map((a)=>'${a['text']} ۝').join(' '),textAlign:TextAlign.justify,style:const TextStyle(fontSize:25,height:2.1,color:green))),const SizedBox(height:12),const Text('النص القرآني محمّل عبر واجهة قرآن على الإنترنت؛ يلزم الاتصال للقراءة.',textAlign:TextAlign.center,style:TextStyle(color:Colors.black54))]))]);}

const adhkar = [
 ('سُبْحَانَ اللَّهِ وَبِحَمْدِهِ','100 مرة'),('أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ','100 مرة'),('لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ','حسب الاستطاعة'),('سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَلَا إِلَهَ إِلَّا اللَّهُ، وَاللَّهُ أَكْبَرُ','ذكر جامع')];
class AdhkarTab extends StatelessWidget{const AdhkarTab({super.key});@override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(14),children:[const Text('أذكار مختارة',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:8),...adhkar.map((a)=>Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Text(a.$1,textAlign:TextAlign.center,style:const TextStyle(fontSize:22,height:1.8,color:green)),const SizedBox(height:8),Text(a.$2,textAlign:TextAlign.center,style:const TextStyle(color:Colors.black54))]))))]);}
class TasbeehTab extends StatefulWidget{const TasbeehTab({super.key});@override State<TasbeehTab> createState()=>_TasbeehTabState();}
class _TasbeehTabState extends State<TasbeehTab>{int count=0;@override void initState(){super.initState();SharedPreferences.getInstance().then((p)=>setState(()=>count=p.getInt('tasbeeh')??0));}Future<void> _save(int n)async{final p=await SharedPreferences.getInstance();await p.setInt('tasbeeh',n);}@override Widget build(BuildContext context)=>Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Text('سُبْحَانَ اللَّهِ',style:TextStyle(fontSize:30,color:green)),const SizedBox(height:22),Text('$count',style:const TextStyle(fontSize:58,fontWeight:FontWeight.bold)),const SizedBox(height:18),FilledButton(onPressed:(){setState(()=>count++);_save(count);},style:FilledButton.styleFrom(backgroundColor:green,minimumSize:const Size(170,64)),child:const Text('سبّح',style:TextStyle(fontSize:22))),TextButton(onPressed:(){setState(()=>count=0);_save(0);},child:const Text('تصفير العداد'))]));}

class SettingsTab extends StatefulWidget{const SettingsTab({super.key});@override State<SettingsTab> createState()=>_SettingsTabState();}
class _SettingsTabState extends State<SettingsTab>{final ctrl=TextEditingController(text:'com.google.android.youtube');bool enabled=false;int seconds=30;String status='لم يتم تفعيل خدمة إمكانية الوصول بعد.';@override void initState(){super.initState();_load();}Future<void> _load()async{final p=await SharedPreferences.getInstance();setState((){ctrl.text=p.getString('targetPackages')??'com.google.android.youtube';enabled=p.getBool('reminderEnabled')??false;seconds=p.getInt('reminderSeconds')??30;});}Future<void> _save()async{final p=await SharedPreferences.getInstance();final targets=ctrl.text.split(',').map((e)=>e.trim()).where((e)=>e.isNotEmpty).toList();await p.setString('targetPackages',targets.join(','));await p.setBool('reminderEnabled',enabled);await p.setInt('reminderSeconds',seconds);try{await channel.invokeMethod('openAccessibilitySettings');setState(()=>status='احفظ الإعدادات، ثم فعّل خدمة نور من شاشة إمكانية الوصول إن ظهرت.');}catch(_){setState(()=>status='تم حفظ الإعدادات. افتح إعدادات إمكانية الوصول في الهاتف وفعّل خدمة نور إن كانت متاحة.');}}
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('التذكير قبل التطبيقات',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:8),const Text('اكتب أسماء الحزم مفصولة بفاصلة. المثال الافتراضي هو يوتيوب. تختلف أسماء الحزم من تطبيق لآخر.'),const SizedBox(height:12),TextField(controller:ctrl,decoration:const InputDecoration(labelText:'أسماء حزم التطبيقات',hintText:'com.google.android.youtube',border:OutlineInputBorder()),maxLines:3),const SizedBox(height:12),SwitchListTile(title:const Text('تشغيل التذكير'),subtitle:const Text('يتطلب منح خدمة إمكانية الوصول يدويًا'),value:enabled,onChanged:(v)=>setState(()=>enabled=v)),const SizedBox(height:8),Text('مدة التذكير: $seconds ثانية'),Slider(value:seconds.toDouble(),min:10,max:60,divisions:5,label:'$seconds ثانية',onChanged:(v)=>setState(()=>seconds=v.round())),FilledButton(onPressed:_save,style:FilledButton.styleFrom(backgroundColor:green),child:const Text('حفظ وفتح إعدادات الخدمة')),const SizedBox(height:12),Text(status),const Divider(height:30),const Text('معلومات',style:TextStyle(fontWeight:FontWeight.bold)),const Text('تطبيق نور نموذج أولي. تذكير التطبيقات قد لا يعمل على كل الأجهزة، ولا يمكن تجاوز قيود أندرويد أو ضمان ظهور التذكير في جميع الحالات. مواقيت الصلاة والقبلة والتنبيهات لم تُفعّل في هذه النسخة.')]);}
