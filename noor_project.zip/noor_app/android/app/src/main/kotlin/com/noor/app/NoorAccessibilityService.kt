package com.noor.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.CountDownTimer
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class NoorAccessibilityService : AccessibilityService() {
    private var overlay: LinearLayout? = null
    private var timer: CountDownTimer? = null
    private var lastPackage = ""
    private var lastShownAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui" || pkg == "android") return
        val prefs = getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE)
        val targets = prefs.getString("flutter.targetPackages", "com.google.android.youtube")
            .orEmpty().split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (pkg !in targets) { lastPackage = ""; return }
        if (!prefs.getBoolean("flutter.reminderEnabled", false) || overlay != null) return
        if (pkg == lastPackage && System.currentTimeMillis() - lastShownAt < 2000) return
        lastPackage = pkg
        lastShownAt = System.currentTimeMillis()
        showReminder(prefs.getString("flutter.reminderText", "اجعل للقرآن نصيبًا من يومك").orEmpty(), prefs.getInt("flutter.reminderSeconds", 30))
    }

    private fun showReminder(text: String, seconds: Int) {
        removeOverlay()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 28)
            setBackgroundColor(Color.rgb(18, 61, 50))
        }
        val title = TextView(this).apply {
            this.text = "نور — لحظة مع القرآن"
            textSize = 25f; setTextColor(Color.rgb(215,181,109)); gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        val scroll = ScrollView(this)
        val quran = TextView(this).apply {
            this.text = if (text.isBlank()) "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\n\nفَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ" else text
            textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(4, 28, 4, 28)
        }
        scroll.addView(quran)
        val countdown = TextView(this).apply { textSize = 18f; setTextColor(Color.rgb(215,181,109)); gravity = Gravity.CENTER; setPadding(0, 16, 0, 0) }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(countdown, LinearLayout.LayoutParams(-1, -2))
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        try { wm.addView(root, params); overlay = root } catch (_: Exception) { return }
        val duration = seconds.coerceIn(10, 60) * 1000L
        timer = object : CountDownTimer(duration, 1000) {
            override fun onTick(millisUntilFinished: Long) { countdown.text = "سيختفي التذكير بعد ${millisUntilFinished / 1000} ثانية" }
            override fun onFinish() { removeOverlay() }
        }.start()
    }

    private fun removeOverlay() {
        timer?.cancel(); timer = null
        val v = overlay ?: return
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Exception) { }
        overlay = null
    }
    override fun onInterrupt() { removeOverlay() }
    override fun onDestroy() { removeOverlay(); super.onDestroy() }
}
